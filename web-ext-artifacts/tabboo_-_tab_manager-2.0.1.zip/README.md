Tab manager for the amazing Firefox Quantum.
Inspired by the Chrome extension Session Buddy.

Design by nojuan - https://dribbble.com/nojuan , http://nojuan.tv/

Code by Digital Hank - http://digitalhank.se/ , https://github.com/digitalhank
Currently pending acceptance to Firefox Add-On store.

INSTALLATION (until it's available on the Add-On store)

1. Clone repo
2. npm install -g web-ext
3. web-ext run

Make sure you have Firefox Quantum installed.
